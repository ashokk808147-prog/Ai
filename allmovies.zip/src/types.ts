export interface Movie {
  id: string;
  title: string;
  description: string;
  quality: string;
  rating: number;
  imageUrl: string;
}
