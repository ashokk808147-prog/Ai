import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Star, Play, Loader2 } from 'lucide-react';
import { QualityBadge } from './MovieSection';
import { Movie } from '../types';

interface InfiniteGridProps {
  title: string;
  description: string;
  initialData: Movie[];
  loadMoreData: (page: number) => Movie[];
}

export function InfiniteGrid({ title, description, initialData, loadMoreData }: InfiniteGridProps) {
  const [items, setItems] = useState<Movie[]>(initialData.slice(0, 10));
  const [page, setPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const observer = useRef<IntersectionObserver | null>(null);

  const lastElementRef = useCallback((node: HTMLDivElement | null) => {
    if (isLoading) return;
    if (observer.current) observer.current.disconnect();
    
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        setPage(prevPage => prevPage + 1);
      }
    });
    
    if (node) observer.current.observe(node);
  }, [isLoading]);

  useEffect(() => {
    if (page === 1) return;
    
    setIsLoading(true);
    // Simulate network delay for infinite scroll loading effect
    const timer = setTimeout(() => {
      const newItems = loadMoreData(page);
      setItems(prev => {
        // Ensure no duplicates by ID
        const combined = [...prev, ...newItems];
        const unique = Array.from(new Map(combined.map(item => [item.id, item])).values());
        return unique;
      });
      setIsLoading(false);
    }, 800);
    
    return () => clearTimeout(timer);
  }, [page, loadMoreData]);

  return (
    <section className="mb-6 sm:mb-8 mt-2">
      <div className="mt-4 mb-4">
        <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
          <span className="w-2 h-6 bg-pink-500 rounded-full shadow-[0_0_10px_rgba(219,39,119,0.5)]" />
          {title}
        </h2>
        <p className="text-white/50 text-sm mt-1 ml-4 sm:ml-8">{description}</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6 pb-8">
        {items.map((movie, index) => {
          const isLastElement = items.length === index + 1;
          return (
            <div 
              ref={isLastElement ? lastElementRef : null}
              key={movie.id} 
              className="relative group rounded-xl overflow-hidden bg-[#16161a] border border-white/5 cursor-pointer flex flex-col hover:shadow-[0_8px_30px_rgba(0,0,0,0.5)] transition-shadow aspect-[2/3]"
            >
              <img 
                src={movie.imageUrl} 
                alt={movie.title} 
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105 opacity-60 grayscale group-hover:grayscale-0 group-hover:opacity-100"
                loading="lazy"
              />
              
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/10 opacity-80 group-hover:opacity-60 transition-opacity duration-300 pointer-events-none" />
              
              <div className="absolute top-2 left-2 right-2 flex justify-between items-start z-10">
                <div className="flex items-center gap-1 text-[10px] font-bold bg-black/60 backdrop-blur-md px-1.5 py-0.5 rounded text-yellow-500">
                  <Star size={10} fill="currentColor" />
                  {movie.rating}
                </div>
                <QualityBadge quality={movie.quality} />
              </div>

              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 z-20">
                <button className="w-12 h-12 rounded-full border-2 border-white/50 text-white flex items-center justify-center pl-1 hover:bg-white/20 hover:border-white transition-colors bg-black/40 backdrop-blur-sm">
                  <Play size={20} fill="currentColor" />
                </button>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-4 z-10 pointer-events-none">
                <h3 className="font-bold truncate text-white drop-shadow-md text-sm">
                  {movie.title}
                </h3>
                <p className="text-white/50 mt-1 line-clamp-1 drop-shadow-sm text-xs">
                  {movie.description}
                </p>
              </div>
            </div>
          );
        })}
      </div>
      
      {isLoading && (
        <div className="w-full flex justify-center py-6">
          <Loader2 className="w-8 h-8 animate-spin text-pink-500" />
        </div>
      )}
    </section>
  );
}
