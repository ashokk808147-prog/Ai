import React from 'react';
import { Star, Play, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Movie } from '../types';

export const QualityBadge = ({ quality }: { quality: string }) => {
  let colorClasses = 'bg-white/10 text-white';
  
  if (quality.includes('4K')) {
    colorClasses = 'bg-indigo-500 text-white';
  } else if (quality.includes('BluRay')) {
    colorClasses = 'bg-purple-500 text-white';
  } else if (quality.includes('WebRip')) {
    colorClasses = 'bg-cyan-500 text-white';
  } else if (quality.includes('HDTC')) {
    colorClasses = 'bg-pink-500 text-white';
  }

  return (
    <span className={`px-2 py-0.5 text-[10px] font-bold uppercase rounded ${colorClasses}`}>
      {quality}
    </span>
  );
};

export interface MovieSectionProps {
  title: string;
  description?: string;
  movies: Movie[];
  viewMoreLink?: string;
  viewMoreText?: string;
  showEndCard?: boolean;
  isTop?: boolean;
}

export const MovieSection = ({ title, description, movies, viewMoreLink, viewMoreText = "View More", showEndCard = false, isTop = false }: MovieSectionProps) => {
  return (
    <section className="mb-6 sm:mb-8 mt-2">
      {/* Section Header */}
      <div className="mt-4 mb-4">
        <div className="flex items-center gap-3 sm:gap-4">
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <span className="w-2 h-6 bg-pink-500 rounded-full shadow-[0_0_10px_rgba(219,39,119,0.5)]" />
            {title}
          </h2>
          {viewMoreLink && (
            <Link to={viewMoreLink} className="flex items-center gap-1 px-2.5 py-1 sm:px-3 sm:py-1 rounded bg-white/5 border border-white/10 text-[10px] sm:text-xs font-bold text-white hover:bg-white/10 hover:border-pink-500/50 transition-all uppercase tracking-widest group whitespace-nowrap">
              {viewMoreText}
              <ChevronRight size={14} className="text-pink-500 group-hover:translate-x-1 transition-transform" />
            </Link>
          )}
        </div>
        {description && <p className="text-white/50 text-sm mt-1 ml-4 sm:ml-8">{description}</p>}
      </div>

      {/* Movie Scroll Container */}
      <div className="flex gap-4 sm:gap-6 overflow-x-auto pb-4 scrollbar-hide snap-x snap-mandatory -mx-4 px-4 sm:mx-0 sm:px-0">
        {movies.map((movie) => (
          <div 
            key={movie.id} 
            className={`flex-none snap-start relative group rounded-xl overflow-hidden bg-[#16161a] border border-white/5 cursor-pointer flex flex-col hover:shadow-[0_8px_30px_rgba(0,0,0,0.5)] transition-shadow 
            ${isTop ? 'w-[85vw] sm:w-[45vw] md:w-[400px] aspect-[16/9]' : 'w-[45vw] sm:w-[25vw] md:w-[200px] lg:w-[220px] aspect-[2/3]'}`}
          >
            {/* Poster Image */}
            <img 
              src={movie.imageUrl} 
              alt={movie.title} 
              className={`absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105 opacity-60 ${!isTop && 'grayscale'} group-hover:grayscale-0 group-hover:opacity-100`}
              loading="lazy"
            />
            
            {/* Gradient Overlays */}
            <div className={`absolute inset-0 bg-gradient-to-t from-black ${isTop ? 'via-black/20' : 'via-black/40'} to-black/10 opacity-80 group-hover:opacity-60 transition-opacity duration-300 pointer-events-none`} />
            
            {/* Top Bar (Quality & Rating) */}
            <div className="absolute top-2 left-2 right-2 flex justify-between items-start z-10">
              <div className="flex items-center gap-1 text-[10px] font-bold bg-black/60 backdrop-blur-md px-1.5 py-0.5 rounded text-yellow-500">
                <Star size={10} fill="currentColor" />
                {movie.rating}
              </div>
              <QualityBadge quality={movie.quality} />
            </div>

            {/* Hover Play Button (Centered) */}
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 z-20">
              <button className="w-12 h-12 rounded-full border-2 border-white/50 text-white flex items-center justify-center pl-1 hover:bg-white/20 hover:border-white transition-colors bg-black/40 backdrop-blur-sm">
                <Play size={20} fill="currentColor" />
              </button>
            </div>

            {/* Bottom Content */}
            <div className="absolute bottom-0 left-0 right-0 p-4 z-10 pointer-events-none">
              <h3 className={`font-bold truncate text-white drop-shadow-md ${isTop ? 'text-lg sm:text-xl' : 'text-sm'}`}>
                {movie.title}
              </h3>
              <p className={`text-white/50 mt-1 line-clamp-1 drop-shadow-sm ${isTop ? 'text-sm' : 'text-xs'}`}>
                {movie.description}
              </p>
            </div>
            
            {/* Top Badge Overlay */}
            {isTop && (
               <div className="absolute top-0 right-0 p-4 opacity-50 z-0 hidden sm:block pointer-events-none">
                  <span className="text-6xl font-black italic text-transparent bg-clip-text bg-gradient-to-b from-white to-transparent">
                     #{movies.indexOf(movie) + 1}
                  </span>
               </div>
            )}
          </div>
        ))}

        {showEndCard && viewMoreLink && (
          <Link 
            to={viewMoreLink}
            className={`flex-none snap-start relative rounded-xl border border-white/10 bg-[#16161a] cursor-pointer flex items-center justify-center hover:bg-white/5 hover:border-pink-500/50 transition-all group
            ${isTop ? 'w-[85vw] sm:w-[45vw] md:w-[400px] aspect-[16/9]' : 'w-[45vw] sm:w-[25vw] md:w-[200px] lg:w-[220px] aspect-[2/3]'}`}
          >
            <div className="flex flex-col items-center gap-3 text-white/50 group-hover:text-pink-400 transition-colors">
              <div className="w-12 h-12 rounded-full border-2 border-currentColor flex items-center justify-center group-hover:scale-110 transition-transform bg-white/5">
                <ChevronRight size={24} />
              </div>
              <span className="font-bold uppercase tracking-widest text-sm">{viewMoreText}</span>
            </div>
          </Link>
        )}
      </div>
    </section>
  );
};
