import React, { useCallback } from 'react';
import { DATA_ALL_MOVIES, MOCK_MOVIES } from '../data/movies';
import { InfiniteGrid } from '../components/InfiniteGrid';

export function AllMovies() {
  const loadMoreData = useCallback((page: number) => {
    // Generate mock data for the next page to simulate infinite scrolling
    return MOCK_MOVIES.map((m, i) => ({
      ...m,
      id: `am-load-${page}-${m.id}-${i}`
    }));
  }, []);

  return (
    <InfiniteGrid 
      title="All Movies"
      description="Explore our entire movie collection."
      initialData={DATA_ALL_MOVIES}
      loadMoreData={loadMoreData}
    />
  );
}
