import React from 'react';
import { Download } from 'lucide-react';

export function HowToDownload() {
  return (
    <section className="mb-6 sm:mb-8 mt-2 max-w-5xl mx-auto px-4">
      <div className="mt-8 mb-10 text-center">
        <h2 className="text-3xl sm:text-5xl font-black tracking-tighter bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent flex items-center justify-center gap-3">
          <Download className="text-pink-500" size={36} />
          How to Download
        </h2>
        <p className="text-white/50 text-sm sm:text-lg mt-4 max-w-2xl mx-auto">
          Follow our simple step-by-step video guide to learn how to download your favorite movies and series directly to your device.
        </p>
      </div>

      <div className="rounded-2xl overflow-hidden border-2 border-white/10 bg-[#16161a] shadow-[0_0_40px_rgba(219,39,119,0.15)] relative group aspect-video">
        <video 
          controls 
          className="w-full h-full object-cover"
          poster="https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=1200&q=80"
        >
          <source src="https://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4" />
          Your browser does not support HTML video.
        </video>
      </div>

      <div className="mt-16 grid gap-6 sm:grid-cols-3">
        <div className="bg-white/5 border border-white/10 p-6 sm:p-8 rounded-2xl hover:border-pink-500/50 hover:bg-white/10 transition-all group">
          <div className="w-12 h-12 rounded-full bg-pink-500/20 text-pink-500 flex items-center justify-center font-black text-xl mb-6 shadow-[0_0_15px_rgba(219,39,119,0.3)] group-hover:scale-110 transition-transform">
            1
          </div>
          <h3 className="font-bold text-xl mb-3 text-white">Find your content</h3>
          <p className="text-white/50 text-sm leading-relaxed">
            Use our top search bar or browse through the specialized categories to find the exact movie or series you want to watch.
          </p>
        </div>
        
        <div className="bg-white/5 border border-white/10 p-6 sm:p-8 rounded-2xl hover:border-purple-500/50 hover:bg-white/10 transition-all group">
          <div className="w-12 h-12 rounded-full bg-purple-500/20 text-purple-500 flex items-center justify-center font-black text-xl mb-6 shadow-[0_0_15px_rgba(168,85,247,0.3)] group-hover:scale-110 transition-transform">
            2
          </div>
          <h3 className="font-bold text-xl mb-3 text-white">Choose Quality</h3>
          <p className="text-white/50 text-sm leading-relaxed">
            Scroll down to the links section and select your preferred resolution (4K, 1080p, or 720p) depending on your internet speed and storage.
          </p>
        </div>

        <div className="bg-white/5 border border-white/10 p-6 sm:p-8 rounded-2xl hover:border-indigo-500/50 hover:bg-white/10 transition-all group">
          <div className="w-12 h-12 rounded-full bg-indigo-500/20 text-indigo-500 flex items-center justify-center font-black text-xl mb-6 shadow-[0_0_15px_rgba(99,102,241,0.3)] group-hover:scale-110 transition-transform">
            3
          </div>
          <h3 className="font-bold text-xl mb-3 text-white">Start Download</h3>
          <p className="text-white/50 text-sm leading-relaxed">
            Click the download button, bypass any short advertisement pages, and your high-speed download will begin completely free of charge.
          </p>
        </div>
      </div>
    </section>
  );
}
