import React from 'react';
import { Search } from 'lucide-react';
import { MovieSection } from '../components/MovieSection';
import { DATA_TOP_3, DATA_NEW_MOVIES, DATA_NEW_SERIES, DATA_NEW_ANIME, DATA_ALL_MOVIES, DATA_ALL_SERIES, DATA_ALL_ANIME, MOCK_MOVIES } from '../data/movies';
import { Movie } from '../types';

export function Home({ searchQuery }: { searchQuery: string }) {

  const uniqueMovies = MOCK_MOVIES.reduce((acc, curr) => {
    if (!acc.find(m => m.title === curr.title)) {
       acc.push(curr);
    }
    return acc;
  }, [] as Movie[]);

  const searchResults = searchQuery.length > 0 
    ? uniqueMovies.filter(movie => movie.title.toLowerCase().includes(searchQuery.toLowerCase().trim()))
    : [];

  return (
    <>
      {searchQuery ? (
        <div className="pt-4">
          <MovieSection 
            title={`Search Results for "${searchQuery}"`} 
            description={`${searchResults.length} titles found`}
            movies={searchResults} 
          />
          {searchResults.length === 0 && (
            <div className="text-center py-20 text-white/50 flex flex-col items-center">
              <Search size={48} className="mb-4 opacity-20" />
              <p>No titles found. Try searching for something else.</p>
            </div>
          )}
        </div>
      ) : (
        <>
          <MovieSection 
            title="Top 3 Trending" 
            description="The most watched titles across all categories right now." 
            movies={DATA_TOP_3} 
            isTop={true} 
          />
      
          <MovieSection 
            title="New Movies" 
            movies={DATA_NEW_MOVIES} 
            viewMoreLink="/movies" 
          />
          
          <MovieSection 
            title="New Series" 
            movies={DATA_NEW_SERIES} 
            viewMoreLink="/series" 
          />
          
          <MovieSection 
            title="New Anime" 
            movies={DATA_NEW_ANIME} 
            viewMoreLink="/anime" 
          />
          
          <MovieSection 
            title="All Movies" 
            movies={DATA_ALL_MOVIES} 
            viewMoreLink="/movies" 
            viewMoreText="View All"
            showEndCard={true}
          />
          
          <MovieSection 
            title="All Series" 
            movies={DATA_ALL_SERIES} 
            viewMoreLink="/series" 
            viewMoreText="View All"
            showEndCard={true}
          />
          
          <MovieSection 
            title="All Anime" 
            movies={DATA_ALL_ANIME} 
            viewMoreLink="/anime" 
            viewMoreText="View All"
            showEndCard={true}
          />
        </>
      )}
    </>
  );
}
