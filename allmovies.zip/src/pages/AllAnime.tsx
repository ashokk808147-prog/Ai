import React, { useCallback } from 'react';
import { DATA_ALL_ANIME, MOCK_MOVIES } from '../data/movies';
import { InfiniteGrid } from '../components/InfiniteGrid';

export function AllAnime() {
  const loadMoreData = useCallback((page: number) => {
    // Generate mock data for the next page to simulate infinite scrolling
    return MOCK_MOVIES.map((m, i) => ({
      ...m,
      id: `aa-load-${page}-${m.id}-${i}`
    }));
  }, []);

  return (
    <InfiniteGrid 
      title="All Anime"
      description="Explore our entire anime collection."
      initialData={DATA_ALL_ANIME}
      loadMoreData={loadMoreData}
    />
  );
}
