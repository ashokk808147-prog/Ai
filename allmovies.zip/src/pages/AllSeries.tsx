import React, { useCallback } from 'react';
import { DATA_ALL_SERIES, MOCK_MOVIES } from '../data/movies';
import { InfiniteGrid } from '../components/InfiniteGrid';

export function AllSeries() {
  const loadMoreData = useCallback((page: number) => {
    // Generate mock data for the next page to simulate infinite scrolling
    return MOCK_MOVIES.map((m, i) => ({
      ...m,
      id: `as-load-${page}-${m.id}-${i}`
    }));
  }, []);

  return (
    <InfiniteGrid 
      title="All Series"
      description="Explore our entire series collection."
      initialData={DATA_ALL_SERIES}
      loadMoreData={loadMoreData}
    />
  );
}
