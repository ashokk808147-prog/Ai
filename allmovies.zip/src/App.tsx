import React, { useState, useRef, useEffect } from 'react';
import { Search, Menu, X, Bell, MessageCircle } from 'lucide-react';
import { HashRouter as Router, Routes, Route, Link, NavLink, useLocation } from 'react-router-dom';
import { Home } from './pages/Home';
import { AllMovies } from './pages/AllMovies';

import { AllSeries } from './pages/AllSeries';
import { AllAnime } from './pages/AllAnime';
import { HowToDownload } from './pages/HowToDownload';

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

export default function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen bg-[#0a0a0b] flex flex-col font-sans text-white relative overflow-x-hidden">
        {/* Background ambient light - reduced opacity for Geometric Balance */}
        <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-pink-600/5 rounded-full blur-[120px] pointer-events-none" />
        <div className="fixed bottom-0 right-0 w-[500px] h-[500px] bg-purple-600/5 rounded-full blur-[120px] pointer-events-none" />

        {/* Navbar */}
        <nav className="sticky top-0 z-50 bg-[#0e0e10]/80 backdrop-blur-md border-b border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              <div className="flex items-center gap-4">
                <button 
                  className="p-2 -ml-2 text-white/70 hover:text-white transition-colors lg:hidden"
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                >
                  {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </button>
                <Link to="/" className="hidden sm:block text-xl sm:text-2xl font-black tracking-tighter bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent truncate max-w-[150px] md:max-w-none">
                  ALL MOVIES & SERIES
                </Link>
                <Link to="/" className="sm:hidden text-xl font-black tracking-tighter bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent truncate">
                  ALL MOVIES & SERIES
                </Link>
              </div>

              <div className="hidden lg:flex items-center gap-8 text-sm font-medium text-white/70 uppercase tracking-widest">
                <NavLink to="/" end className={({ isActive }) => `transition-colors duration-300 ${isActive ? 'text-pink-500 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]' : 'hover:text-white'}`}>Home Page</NavLink>
                <NavLink to="/movies" className={({ isActive }) => `transition-colors duration-300 ${isActive ? 'text-pink-500 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]' : 'hover:text-white'}`}>Movies</NavLink>
                <NavLink to="/series" className={({ isActive }) => `transition-colors duration-300 ${isActive ? 'text-pink-500 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]' : 'hover:text-white'}`}>Series</NavLink>
                <NavLink to="/anime" className={({ isActive }) => `transition-colors duration-300 ${isActive ? 'text-pink-500 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]' : 'hover:text-white'}`}>Anime</NavLink>
                <NavLink to="/how-to-download" className={({ isActive }) => `transition-colors duration-300 ${isActive ? 'text-pink-500 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]' : 'hover:text-white'}`}>How to Download</NavLink>
              </div>

              <div className="flex items-center gap-2 sm:gap-4">
                <div className="relative flex items-center">
                  <div 
                    className={`flex items-center bg-white/5 border transition-all duration-300 rounded-full px-3 py-1.5 cursor-text ${isSearchFocused || searchQuery ? 'border-pink-500/50 shadow-[0_0_10px_rgba(219,39,119,0.2)] w-40 sm:w-64 bg-white/10' : 'border-white/10 w-10 sm:w-48 overflow-hidden hover:bg-white/10'}`}
                    onClick={() => {
                      setIsSearchFocused(true);
                      searchInputRef.current?.focus();
                    }}
                  >
                    <Search size={16} className={`text-white/50 cursor-pointer ${isSearchFocused || searchQuery ? 'min-w-[16px]' : 'min-w-[16px] sm:min-w-[16px] mx-auto sm:mx-0'}`} />
                    <input 
                      ref={searchInputRef}
                      type="text" 
                      placeholder="Search titles..." 
                      className={`bg-transparent border-none outline-none text-sm text-white w-full placeholder:text-white/30 ml-2 transition-opacity ${!(isSearchFocused || searchQuery) ? 'opacity-0 sm:opacity-100 hidden sm:block' : ''}`}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onFocus={() => setIsSearchFocused(true)}
                      onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                    />
                  </div>
                </div>

                <button className="p-2 text-white/70 hover:text-white transition-colors relative hidden sm:block">
                  <Bell size={20} />
                  <span className="absolute top-2 right-2 w-2 h-2 bg-pink-500 rounded-full shadow-[0_0_8px_rgba(236,72,153,0.8)]" />
                </button>
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center border-2 border-white/10 sm:ml-2 overflow-hidden flex-shrink-0">
                  <span className="text-[10px] sm:text-xs font-bold text-white">JD</span>
                </div>
              </div>
            </div>
          </div>
        </nav>

        {/* Mobile Menu Overlay */}
        {isMobileMenuOpen && (
          <div 
            className="fixed inset-0 bg-black/80 z-[60] lg:hidden backdrop-blur-sm"
            style={{ position: 'fixed' }}
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}

        {/* Mobile Menu Drawer */}
        <div 
          className={`fixed inset-y-0 left-0 w-[70vw] sm:w-[50vw] bg-[#0e0e10] border-r border-white/5 z-[70] transform transition-transform duration-300 ease-in-out lg:hidden shadow-2xl flex flex-col ${
            isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
          style={{ position: 'fixed' }}
        >
          <div className="flex items-center justify-between p-4 sm:px-6 border-b border-white/5 h-20">
            <span className="text-lg font-black tracking-tighter bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
              MENU
            </span>
            <button 
              className="p-2 -mr-2 text-white/70 hover:text-white transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <X size={24} />
            </button>
          </div>
          <div className="flex flex-col p-4 sm:px-6 gap-2 text-sm sm:text-base font-bold uppercase tracking-widest overflow-y-auto h-full">
            <NavLink to="/" end className={({ isActive }) => `p-3 rounded-lg transition-colors pl-4 border-l-2 ${isActive ? 'text-pink-500 border-pink-500 hover:bg-white/5 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]' : 'text-white/70 border-transparent hover:text-white hover:bg-white/5'}`} onClick={() => setIsMobileMenuOpen(false)}>Home Page</NavLink>
            <NavLink to="/movies" className={({ isActive }) => `p-3 rounded-lg transition-colors pl-4 border-l-2 ${isActive ? 'text-pink-500 border-pink-500 hover:bg-white/5 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]' : 'text-white/70 border-transparent hover:text-white hover:bg-white/5'}`} onClick={() => setIsMobileMenuOpen(false)}>Movies</NavLink>
            <NavLink to="/series" className={({ isActive }) => `p-3 rounded-lg transition-colors pl-4 border-l-2 ${isActive ? 'text-pink-500 border-pink-500 hover:bg-white/5 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]' : 'text-white/70 border-transparent hover:text-white hover:bg-white/5'}`} onClick={() => setIsMobileMenuOpen(false)}>Series</NavLink>
            <NavLink to="/anime" className={({ isActive }) => `p-3 rounded-lg transition-colors pl-4 border-l-2 ${isActive ? 'text-pink-500 border-pink-500 hover:bg-white/5 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]' : 'text-white/70 border-transparent hover:text-white hover:bg-white/5'}`} onClick={() => setIsMobileMenuOpen(false)}>Anime</NavLink>
            <NavLink to="/how-to-download" className={({ isActive }) => `p-3 rounded-lg transition-colors pl-4 border-l-2 ${isActive ? 'text-pink-500 border-pink-500 hover:bg-white/5 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]' : 'text-white/70 border-transparent hover:text-white hover:bg-white/5'}`} onClick={() => setIsMobileMenuOpen(false)}>How to Download</NavLink>
          </div>
        </div>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-2 pb-12 flex-1 w-full">
          <Routes>
            <Route path="/" element={<Home searchQuery={searchQuery} />} />
            <Route path="/movies" element={<AllMovies />} />
            <Route path="/series" element={<AllSeries />} />
            <Route path="/anime" element={<AllAnime />} />
            <Route path="/how-to-download" element={<HowToDownload />} />
          </Routes>
        </main>

        {/* Floating Contact Button */}
        <div className="fixed bottom-8 right-8 z-50">
          <button 
            className="w-14 h-14 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center shadow-[0_8px_25px_rgba(219,39,119,0.5)] border-2 border-white/20 hover:scale-105 transition-transform group"
            aria-label="Contact us"
          >
            <MessageCircle size={24} className="text-white group-hover:animate-pulse" />
            <span className="absolute right-full mr-4 top-1/2 -translate-y-1/2 whitespace-nowrap bg-[#16161a] text-white text-xs px-3 py-1.5 rounded opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity duration-300 border border-white/10 font-bold uppercase tracking-wider">
              Need Help?
            </span>
          </button>
        </div>

        {/* Global styles for hiding scrollbar cleanly across browsers */}
        <style dangerouslySetInnerHTML={{__html: `
          .scrollbar-hide::-webkit-scrollbar {
              display: none;
          }
          .scrollbar-hide {
              -ms-overflow-style: none;
              scrollbar-width: none;
          }
        `}} />
      </div>
    </Router>
  );
}
