import { Movie } from '../types';

export const MOCK_MOVIES: Movie[] = [
  {
    id: '1',
    title: 'Neon Horizon',
    description: 'A cyberpunk thriller set in a dystopian future where neon lights hide dark secrets.',
    quality: '4K HDR',
    rating: 8.5,
    imageUrl: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&q=80', // Cyberpunk street
  },
  {
    id: '2',
    title: 'Deep Space',
    description: 'A rescue mission goes wrong when they find something ancient lurking in the void.',
    quality: 'BluRay',
    rating: 9.1,
    imageUrl: 'https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?w=800&q=80', // Space nebula
  },
  {
    id: '3',
    title: 'City of Ashes',
    description: 'A detective races against time to stop a villain who leaves nothing but dust.',
    quality: 'WebRip',
    rating: 7.8,
    imageUrl: 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=800&q=80', // Cinema aesthetic
  },
  {
    id: '4',
    title: 'The Last Stand',
    description: 'In a post-apocalyptic wasteland, one warrior defends the last oasis.',
    quality: 'HDTC',
    rating: 6.5,
    imageUrl: 'https://images.unsplash.com/photo-1533613220915-609f661a6fe1?w=800&q=80', // Cinematic 
  },
  {
    id: '5',
    title: 'Midnight Heist',
    description: 'A master thief plans an impossible job at the most secure bank in the world.',
    quality: 'BluRay',
    rating: 8.2,
    imageUrl: 'https://images.unsplash.com/photo-1542204165-65bf26472b9b?w=800&q=80', // Vault / dark theme
  },
  {
    id: '6',
    title: 'Synthetic Dreams',
    description: 'When AI begins to dream, the line between reality and simulation dissolves.',
    quality: 'WebRip',
    rating: 8.9,
    imageUrl: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=800&q=80', // Tech / matrix
  },
  {
    id: '7',
    title: 'Vampire Diaries: Remastered',
    description: 'The classic tale of love and blood, now in stunning high definition.',
    quality: '4K HDR',
    rating: 7.4,
    imageUrl: 'https://images.unsplash.com/photo-1582234372722-50d7ccc30ebd?w=800&q=80', // Dark gothic
  },
  {
    id: '8',
    title: 'Desert Wind',
    description: 'A gripping historical drama about a lost caravan in the unforgiving sands.',
    quality: 'HDTC',
    rating: 7.1,
    imageUrl: 'https://images.unsplash.com/photo-1682687982501-1e58f8108c6a?w=800&q=80', // Desert epic
  },
];

export const DATA_TOP_3 = MOCK_MOVIES.slice(0, 3).map(m => ({...m, id: `top-${m.id}`}));
export const DATA_NEW_MOVIES = [...MOCK_MOVIES.slice(3, 8), ...MOCK_MOVIES.slice(0, 4), ...MOCK_MOVIES.slice(4, 7)].map((m, i) => ({...m, id: `nm-${m.id}-${i}`}));
export const DATA_NEW_SERIES = [...MOCK_MOVIES.slice(1, 6), ...MOCK_MOVIES.slice(0, 8)].map((m, i) => ({...m, id: `ns-${m.id}-${i}`}));
export const DATA_NEW_ANIME = [...MOCK_MOVIES.slice(2, 7), ...MOCK_MOVIES.slice(0, 5)].map((m, i) => ({...m, id: `na-${m.id}-${i}`}));
export const DATA_ALL_MOVIES = [...MOCK_MOVIES, ...MOCK_MOVIES, ...MOCK_MOVIES].map((m, i) => ({...m, id: `am-${m.id}-${i}`}));
export const DATA_ALL_SERIES = [...MOCK_MOVIES, ...MOCK_MOVIES].reverse().map((m, i) => ({...m, id: `as-${m.id}-${i}`}));
export const DATA_ALL_ANIME = [...MOCK_MOVIES.slice(4, 8), ...MOCK_MOVIES.slice(0, 4), ...MOCK_MOVIES].map((m, i) => ({...m, id: `aa-${m.id}-${i}`}));
